package Main.observer;

import Main.models.property.Property;

public interface Observer {
    void update(Property p);
}

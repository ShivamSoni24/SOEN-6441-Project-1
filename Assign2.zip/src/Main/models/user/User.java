package Main.models.user;

public abstract class User implements Cloneable {
    private static int counter = 0;
    String id;
    String name;
    String email;
    String phoneNo;

    public User(String name, String email, String phoneNo) {
        this.id = String.valueOf(++counter);
        this.email = email;
        this.phoneNo = phoneNo;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    @Override
    public User clone() {
        try {
            return (User) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}

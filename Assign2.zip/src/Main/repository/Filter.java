package Main.repository;
public enum Filter {
    ALL,
    RENTED,
    VACANT
}
